export { default as CATEGORIES } from './categories';
export { default as COUNTDOWN_TIME } from './countdownTime';
export { default as DIFFICULTY } from './difficulty';
export { default as NUM_OF_QUESTIONS } from './numOfQuestions';
export { default as QUESTIONS_TYPE } from './questionsType';
